__version__ = '2.1.3'
__author__ = 'Matt Nishi-Broach'
__license__ = 'MIT'
__copyright__ = 'Copyright 2015-2018 Matt Nishi-Broach'

# Version synonym
VERSION = __version__
